import io, os, re, json, math
from pathlib import Path
from typing import List, Dict, Any

import cv2
import fitz
import numpy as np
from PIL import Image
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

BASE = Path(__file__).resolve().parent.parent
UPLOADS = BASE / "uploads"
UPLOADS.mkdir(exist_ok=True)

app = FastAPI(title="Rally Route Mapper")
app.mount("/static", StaticFiles(directory=str(BASE / "static")), name="static")

STAGE_RE = re.compile(r"(SS\d+)\s*&\s*(SS\d+)\s*[—-]\s*([^—\n]+)", re.I)

def render_pdf(data: bytes):
    doc = fitz.open(stream=data, filetype="pdf")
    pages = []
    for i, page in enumerate(doc):
        pix = page.get_pixmap(matrix=fitz.Matrix(2, 2), alpha=False)
        img = Image.open(io.BytesIO(pix.tobytes("png"))).convert("RGB")
        out = UPLOADS / f"page_{i+1}.png"
        img.save(out)
        text = page.get_text("text")
        pages.append({"page": i+1, "image": f"/uploads/{out.name}", "text": text})
    return pages

def detect_colours(img: np.ndarray):
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    # Rally maps commonly use strong red and blue route lines.
    masks = {
        "special_stage": cv2.inRange(hsv, np.array([0, 100, 80]), np.array([12, 255, 255])) |
                         cv2.inRange(hsv, np.array([168, 100, 80]), np.array([179, 255, 255])),
        "road_section": cv2.inRange(hsv, np.array([90, 70, 60]), np.array([135, 255, 255]))
    }
    result = {}
    for name, mask in masks.items():
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3,3), np.uint8))
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((5,5), np.uint8))
        n, labels, stats, centroids = cv2.connectedComponentsWithStats(mask, 8)
        components = []
        for idx in range(1, n):
            area = int(stats[idx, cv2.CC_STAT_AREA])
            if area < 80:
                continue
            ys, xs = np.where(labels == idx)
            # Downsample component pixels for browser-friendly output.
            pts = np.column_stack([xs, ys])
            step = max(1, len(pts)//1500)
            components.append({"area": area, "points": pts[::step].tolist()})
        result[name] = components
    return result

def extract_stages(text: str):
    stages = []
    for m in STAGE_RE.finditer(text):
        stages.append({"stages": [m.group(1).upper(), m.group(2).upper()],
                       "name": m.group(3).strip()})
    return stages

@app.get("/", response_class=HTMLResponse)
def index():
    return (BASE / "static" / "index.html").read_text(encoding="utf-8")

@app.get("/api/health")
def health():
    return {"ok": True}

@app.get("/api/config")
def config():
    return {"google_maps_configured": bool(os.getenv("GOOGLE_MAPS_API_KEY"))}

@app.post("/api/upload")
async def upload(file: UploadFile = File(...)):
    if not file.filename:
        raise HTTPException(400, "No file selected")
    ext = Path(file.filename).suffix.lower()
    if ext not in {".pdf",".png",".jpg",".jpeg",".webp"}:
        raise HTTPException(400, "Upload a PDF or image")
    data = await file.read()
    if len(data) > 30 * 1024 * 1024:
        raise HTTPException(413, "File is larger than 30 MB")

    if ext == ".pdf":
        pages = render_pdf(data)
    else:
        name = "page_1.png"
        Image.open(io.BytesIO(data)).convert("RGB").save(UPLOADS / name)
        pages = [{"page":1, "image":f"/uploads/{name}", "text":""}]

    for p in pages:
        img = cv2.imread(str(BASE / p["image"].lstrip("/")))
        p["routes"] = detect_colours(img) if img is not None else {}
        p["stages"] = extract_stages(p["text"])
    return JSONResponse({"filename": file.filename, "pages": pages})

@app.post("/api/geojson")
async def geojson(payload: Dict[str, Any]):
    # Pixel -> lat/lon affine calibration. Three or more control points are required.
    cps = payload.get("control_points", [])
    layers = payload.get("layers", [])
    if len(cps) < 3:
        raise HTTPException(400, "At least 3 calibration points are required")
    A = np.array([[p["x"], p["y"], 1] for p in cps], dtype=float)
    lat = np.array([p["lat"] for p in cps], dtype=float)
    lon = np.array([p["lon"] for p in cps], dtype=float)
    c_lat, *_ = np.linalg.lstsq(A, lat, rcond=None)
    c_lon, *_ = np.linalg.lstsq(A, lon, rcond=None)

    def transform(pt):
        x, y = pt
        row = np.array([x,y,1.0])
        return [float(row @ c_lon), float(row @ c_lat)]

    features = []
    for layer in layers:
        coords = [transform(p) for p in layer.get("points", [])]
        if len(coords) >= 2:
            features.append({"type":"Feature",
                             "properties":{"type":layer.get("type","route"),
                                           "name":layer.get("name","")},
                             "geometry":{"type":"LineString","coordinates":coords}})
    return {"type":"FeatureCollection","features":features}
